#!/bin/bash
set -e
python model.py && python server.py